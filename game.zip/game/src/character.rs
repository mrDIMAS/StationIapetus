use crate::{
    bot::Bot,
    inventory::Inventory,
    level::{
        hit_box::{HitBox, HitBoxDamage, HitBoxHeal, HitBoxMessage, LimbType},
        item::ItemAction,
    },
    player::Player,
    sound::{SoundKind, SoundManager},
    utils,
    weapon::{weapon_mut, WeaponMessage, WeaponMessageData},
    Item, Weapon,
};
use fyrox::{
    core::{
        algebra::{Isometry3, Translation3},
        algebra::{Point3, Vector3},
        log::Log,
        math::ray::Ray,
        pool::Handle,
        reflect::prelude::*,
        some_or_return,
        type_traits::TypeUuidProvider,
        uuid::{uuid, Uuid},
        variable::InheritableVariable,
        visitor::prelude::*,
    },
    fxhash::FxHashSet,
    graph::SceneGraph,
    plugin::error::GameResult,
    resource::model::{ModelResource, ModelResourceExtension},
    scene::{
        collider::Collider,
        graph::{
            physics::{QueryFilter, RayCastOptions},
            Graph,
        },
        node::Node,
        rigidbody::RigidBody,
        Scene,
    },
    script::{RoutingStrategy, ScriptContext, ScriptMessagePayload, ScriptMessageSender},
};
use rapier3d::geometry::Capsule;

#[derive(Copy, Clone, Debug, Default, Eq, PartialEq)]
pub struct DamageDealer {
    pub entity: Handle<Node>,
}

impl DamageDealer {
    pub fn as_character<'a>(&self, graph: &'a Graph) -> Option<(Handle<Node>, &'a Character)> {
        if let Ok(player) = graph.try_get_script_component_of::<Player>(self.entity) {
            return Some((self.entity, &**player));
        }

        if let Ok(bot) = graph.try_get_script_component_of::<Bot>(self.entity) {
            return Some((self.entity, &**bot));
        }

        let script = graph
            .try_get(self.entity)
            .ok()
            .and_then(|node| node.script(0))?;

        let weapon = script.cast::<Weapon>()?;
        let owner_handle = weapon.owner();

        if let Ok(player) = graph.try_get_script_component_of::<Player>(owner_handle) {
            return Some((owner_handle, &**player));
        }
        if let Ok(bot) = graph.try_get_script_component_of::<Bot>(owner_handle) {
            return Some((owner_handle, &**bot));
        }

        None
    }
}

#[derive(Clone, Copy, Debug)]
pub struct DamagePosition {
    pub point: Vector3<f32>,
    pub direction: Vector3<f32>,
}

#[derive(Debug)]
pub enum CharacterMessageData {
    BeganAiming,
    EndedAiming,
    SelectWeapon(ModelResource),
    AddWeapon(ModelResource),
    PickupItem(Handle<Node>),
    DropItems { item: ModelResource, count: u32 },
    UseItem { item: ModelResource },
}

#[derive(Debug, ScriptMessagePayload)]
pub struct CharacterMessage {
    pub character: Handle<Node>,
    pub data: CharacterMessageData,
}

#[derive(Debug, Copy, Clone, Default)]
struct CharacterMovement {
    translation: Vector3<f32>,
    grounded: bool,
}

#[derive(Visit, Reflect, Debug, Clone, TypeUuidProvider)]
#[type_uuid(id = "d768f3b4-5deb-4f1b-9539-a2cf3f311f4e")]
#[visit(optional)]
pub struct Character {
    pub position: Vector3<f32>,
    pub velocity: Vector3<f32>,
    pub has_ground_contact: bool,

    pub capsule_collider: Handle<Collider>,
    pub body: Handle<RigidBody>,

    pub weapons: Vec<Handle<Node>>,
    pub current_weapon: usize,
    pub weapon_pivot: Handle<Node>,

    pub inventory: Inventory,

    pub melee_hit_boxes: InheritableVariable<Vec<Handle<Collider>>>,
    pub attack_sounds: InheritableVariable<Vec<Handle<Node>>>,
    pub punch_sounds: InheritableVariable<Vec<Handle<Node>>>,

    #[reflect(min_value = 0.0, max_value = 20.0)]
    melee_attack_damage: InheritableVariable<f32>,

    #[visit(skip)]
    #[reflect(hidden)]
    pub hit_boxes: FxHashSet<Handle<Collider>>,

    #[reflect(hidden)]
    #[visit(skip)]
    pub melee_attack_context: Option<MeleeAttackContext>,
}

#[derive(Default, Clone, PartialEq, Debug)]
pub struct MeleeAttackContext {
    pub damaged_hitboxes: FxHashSet<Handle<Collider>>,
    pub damaged_characters: FxHashSet<Handle<Node>>,
}

impl Default for Character {
    fn default() -> Self {
        Self {
            position: Default::default(),
            velocity: Default::default(),
            has_ground_contact: false,
            capsule_collider: Default::default(),
            body: Default::default(),
            weapons: Vec::new(),
            current_weapon: 0,
            weapon_pivot: Handle::NONE,
            hit_boxes: Default::default(),
            inventory: Default::default(),
            melee_hit_boxes: Default::default(),
            attack_sounds: Default::default(),
            punch_sounds: Default::default(),
            melee_attack_damage: 20.0.into(),
            melee_attack_context: None,
        }
    }
}

fn parent_character(mut node_handle: Handle<Node>, graph: &Graph) -> Option<Handle<Node>> {
    while let Ok(node) = graph.try_get(node_handle) {
        if node.try_get_script_component::<Character>().is_some() {
            return Some(node_handle);
        }
        node_handle = node.parent();
    }
    None
}

impl Character {
    pub fn stand_still(&mut self) {
        self.velocity = Vector3::zeros();
    }

    pub fn handle_movement(&mut self, scene: &mut Scene, dt: f32) {
        // Gravity.
        self.velocity.y -= 9.81 * dt;

        // Prevent unlimited falling speed
        self.velocity.y = self.velocity.y.max(-20.0);

        // Desire movement for this frame.
        let desired_translation = self.velocity * dt;

        // Todo : collision detection
        let movement = self.move_character(scene, desired_translation, dt);

        // Apply movement.
        self.position += movement.translation;

        // Store ground state.
        self.has_ground_contact = movement.grounded;

        // Stop downward movement when standing on ground.
        if self.has_ground_contact && self.velocity.y < 0.0 {
            self.velocity.y = 0.0;
        }

        // Move Fyrox kinematic body.
        scene.graph[self.body].set_next_kinematic_translation(self.position);
    }

    fn move_character(
        &mut self,
        scene: &Scene,
        desired_translation: Vector3<f32>,
        dt: f32,
    ) -> CharacterMovement {
        let mut result = CharacterMovement {
            translation: Vector3::default(),
            grounded: false,
        };

        if dt <= 0.0 {
            return result;
        }

        if desired_translation.norm_squared() <= f32::EPSILON {
            return result;
        }

        let shape = Capsule::new_y(0.5, 0.4);

        let position = Isometry3 {
            translation: Translation3::from(self.position),
            rotation: Default::default(),
        };

        let filter = QueryFilter {
            exclude_collider: Some(self.capsule_collider.transmute()),
            predicate: Some(&|_, collider| !collider.is_sensor()),
            ..Default::default()
        };

        let physics = &scene.graph.physics;

        // ============================================================
        // 1. MOVEMENT / WALL COLLISION
        // ============================================================

        if desired_translation.norm_squared() > f32::EPSILON {
            let velocity = desired_translation / dt;

            if let Some((_hit, toi)) =
                physics.cast_shape(&scene.graph, &shape, &position, &velocity, dt, true, filter)
            {
                let movement_length = desired_translation.norm();

                let allowed_distance = movement_length * toi.toi;

                if movement_length > f32::EPSILON {
                    result.translation = desired_translation.normalize() * allowed_distance;
                }
                // Fyrox returns the collision normal in world space.
                let normal = Vector3::new(toi.normal1.x, toi.normal1.y, toi.normal1.z);

                // Ground detection.
                //
                // A normal pointing mostly upward means
                // that we hit the floor.
                if normal.y > 0.7 {
                    result.grounded = true;
                }

                // Remove movement going into the wall/floor.
                let remaining = desired_translation - result.translation;

                // Remove the part of the movement going into
                // the collision surface.
                let into_surface = remaining.dot(&normal);

                if into_surface < 0.0 {
                    result.translation += remaining - normal * into_surface;
                }
            } else {
                result.translation = desired_translation;
            }
        }

        let ground_position = Isometry3 {
            translation: Translation3::from(self.position + result.translation),
            rotation: Default::default(),
        };

        let ground_velocity = Vector3::new(0.0, -1.0, 0.0);

        let ground_distance = 0.1;

        if let Some((_hit, toi)) = physics.cast_shape(
            &scene.graph,
            &shape,
            &ground_position,
            &ground_velocity,
            ground_distance,
            true,
            filter,
        ) {
            let normal = Vector3::new(toi.normal1.x, toi.normal1.y, toi.normal1.z);

            if normal.y > 0.7 {
                result.grounded = true
            }
        }
        result
    }

    pub fn on_start(&mut self, ctx: &mut ScriptContext) {
        ctx.scene.graph.update_hierarchical_data();
        self.position = ctx.scene.graph[self.body].global_position();
        self.hit_boxes = ctx
            .scene
            .graph
            .traverse_iter(ctx.handle)
            .filter_map(|(handle, node)| {
                node.try_get_script::<HitBox>().map(|_| handle.transmute())
            })
            .collect::<FxHashSet<_>>()
    }

    pub fn hit_box_iter<'a>(
        &self,
        graph: &'a Graph,
    ) -> impl Iterator<Item = (Handle<Collider>, &'a HitBox)> + use<'a, '_> {
        self.hit_boxes.iter().filter_map(|h| {
            graph
                .try_get_script_component_of::<HitBox>(*h)
                .ok()
                .map(|hitbox| (*h, hitbox))
        })
    }

    pub fn set_position(&mut self, graph: &mut Graph, position: Vector3<f32>) -> GameResult {
        graph
            .try_get_mut(self.body)?
            .local_transform_mut()
            .set_position(position);
        Ok(())
    }

    pub fn most_vulnerable_point(&self, graph: &Graph) -> Vector3<f32> {
        if let Some((head_handle, _)) = self
            .hit_box_iter(graph)
            .find(|(_, h)| *h.limb_type == LimbType::Head)
        {
            graph[head_handle].global_position()
        } else {
            self.position
        }
    }

    pub fn is_limb_sliced_off(&self, graph: &Graph, limb_type: LimbType) -> bool {
        self.hit_box_iter(graph)
            .any(|(_, hitbox)| *hitbox.limb_type == limb_type && hitbox.is_sliced_off())
    }

    pub fn combined_health(&self, graph: &Graph) -> f32 {
        self.hit_box_iter(graph)
            .fold(0.0, |acc, (_, hitbox)| acc + *hitbox.health)
    }

    pub fn most_wounded_hit_box(&self, graph: &Graph) -> Option<Handle<Collider>> {
        let mut min_health = f32::MAX;
        let mut result = None;
        for (handle, hitbox) in self.hit_box_iter(graph) {
            if *hitbox.health < min_health {
                min_health = *hitbox.health;
                result = Some(handle);
            }
        }
        result
    }

    pub fn is_dead(&self, graph: &Graph) -> bool {
        let mut total_hit_boxes = 0;
        let mut sliced_off_hit_boxes = 0;
        let mut combined_health = 0.0;
        for (_, hit_box) in self.hit_box_iter(graph) {
            let is_sliced_off = hit_box.is_sliced_off();

            if *hit_box.critical_for_survival && is_sliced_off {
                return true;
            }

            total_hit_boxes += 1;
            if is_sliced_off {
                sliced_off_hit_boxes += 1;
            }
            combined_health += *hit_box.health;
        }

        combined_health <= 0.0 || sliced_off_hit_boxes >= total_hit_boxes / 4
    }

    pub fn weapon_pivot(&self) -> Handle<Node> {
        self.weapon_pivot
    }

    pub fn weapons(&self) -> &[Handle<Node>] {
        &self.weapons
    }

    pub fn add_weapon(&mut self, weapon: Handle<Node>, graph: &mut Graph) {
        for &other_weapon in self.weapons.iter() {
            graph[other_weapon].set_enabled(false);
        }

        self.current_weapon = self.weapons.len();
        self.weapons.push(weapon);

        self.set_current_weapon_enabled(true, graph);
    }

    pub fn use_item(
        &mut self,
        item: &Item,
        graph: &Graph,
        script_message_sender: &ScriptMessageSender,
    ) {
        match *item.action {
            ItemAction::None => {}
            ItemAction::Heal { amount } => {
                let hit_boxes = self.hit_box_iter(graph).map(|(h, _)| h).collect::<Vec<_>>();
                let hit_box_count = hit_boxes.len();
                for hit_box in hit_boxes {
                    script_message_sender.send_to_target(
                        hit_box,
                        HitBoxMessage::Heal(HitBoxHeal {
                            hit_box,
                            amount: amount / hit_box_count as f32,
                        }),
                    )
                }
            }
        }
    }

    pub fn on_weapon_message(&mut self, weapon_message: &WeaponMessage, graph: &mut Graph) {
        if let WeaponMessageData::Removed = weapon_message.data {
            let removed_weapon = weapon_message.weapon;
            let current_weapon = self.current_weapon();

            if let Some(i) = self.weapons.iter().position(|&w| w == removed_weapon) {
                self.weapons.remove(i);
            }

            if current_weapon == removed_weapon && !self.weapons.is_empty() {
                self.current_weapon = 0;
                self.set_current_weapon_enabled(true, graph);
            }
        }
    }

    pub fn update_melee_attack(
        &mut self,
        scene: &mut Scene,
        message_sender: &ScriptMessageSender,
        self_handle: Handle<Node>,
    ) -> GameResult {
        let attack_context = some_or_return!(self.melee_attack_context.as_mut(), Ok(()));

        let mut need_play_punch_sound = false;

        for melee_hit_box_handle in self.melee_hit_boxes.iter() {
            let melee_hit_box_collider = scene.graph.try_get(*melee_hit_box_handle)?;

            for (collider1, collider2) in melee_hit_box_collider
                .intersects(&scene.graph.physics)
                .map(|i| (i.collider1, i.collider2))
                .chain(
                    melee_hit_box_collider
                        .contacts(&scene.graph.physics)
                        .map(|i| (i.collider1, i.collider2)),
                )
            {
                let intersected_hit_box = if collider1 == *melee_hit_box_handle {
                    collider2
                } else {
                    collider1
                };

                if scene
                    .graph
                    .try_get_script_of::<HitBox>(intersected_hit_box)
                    .is_err()
                {
                    continue;
                }

                if self.hit_boxes.contains(&intersected_hit_box) {
                    continue;
                }

                if attack_context
                    .damaged_hitboxes
                    .contains(&intersected_hit_box)
                {
                    continue;
                }
                attack_context.damaged_hitboxes.insert(intersected_hit_box);

                // Do not over-damage characters.
                if let Some(parent_character) =
                    parent_character(intersected_hit_box.transmute(), &scene.graph)
                {
                    if attack_context
                        .damaged_characters
                        .contains(&parent_character)
                    {
                        continue;
                    }
                    attack_context.damaged_characters.insert(parent_character);
                }

                need_play_punch_sound = true;

                message_sender.send_hierarchical(
                    intersected_hit_box,
                    RoutingStrategy::Up,
                    HitBoxMessage::Damage(HitBoxDamage {
                        hit_box: intersected_hit_box,
                        damage: *self.melee_attack_damage,
                        dealer: DamageDealer {
                            entity: self_handle,
                        },
                        position: Some(DamagePosition {
                            point: melee_hit_box_collider.global_position(),
                            direction: Vector3::new(0.0, 0.0, 1.0),
                        }),
                        is_melee: true,
                    }),
                );
            }
        }

        if need_play_punch_sound {
            utils::try_play_random_sound(&self.punch_sounds, &mut scene.graph);
        }

        Ok(())
    }

    pub fn has_hit_box(&self, handle: Handle<Collider>) -> bool {
        self.hit_boxes.contains(&handle)
    }

    pub fn on_character_message(
        &mut self,
        message_data: &CharacterMessageData,
        scene: &mut Scene,
        self_handle: Handle<Node>,
        script_message_sender: &ScriptMessageSender,
        sound_manager: &SoundManager,
    ) {
        match message_data {
            CharacterMessageData::SelectWeapon(weapon_resource) => {
                self.select_weapon(weapon_resource.clone(), &mut scene.graph)
            }
            CharacterMessageData::AddWeapon(weapon_resource) => {
                assert!(weapon_resource.is_ok());

                if Weapon::is_weapon_resource(weapon_resource) {
                    let weapon = weapon_resource.instantiate(scene);

                    let weapon_script = weapon_mut(weapon, &mut scene.graph);

                    weapon_script.set_owner(self_handle);

                    let inventory = self.inventory_mut();
                    if !inventory.has_item(weapon_resource) {
                        inventory.add_item(weapon_resource, 1)
                    };

                    self.add_weapon(weapon, &mut scene.graph);

                    scene.graph.link_nodes(weapon, self.weapon_pivot());
                } else {
                    Log::warn(format!(
                        "{} is not a weapon resource!",
                        weapon_resource.kind()
                    ));
                }
            }
            &CharacterMessageData::PickupItem(item_handle) => {
                let item_node = &scene.graph[item_handle];
                let item_resource = item_node.root_resource();
                let item = item_node.try_get_script_component::<Item>().unwrap();
                let stack_size = *item.stack_size;
                let position = item_node.global_position();

                if item_node.is_globally_enabled() {
                    if let Some(item_resource) = item_resource {
                        self.inventory.add_item(&item_resource, stack_size);

                        // It might be a weapon-like item.
                        if Weapon::is_weapon_resource(&item_resource) {
                            let mut found_weapon = false;
                            for weapon_handle in self.weapons.iter() {
                                if scene.graph[*weapon_handle].root_resource()
                                    == Some(item_resource.clone())
                                {
                                    found_weapon = true;
                                    break;
                                }
                            }
                            if !found_weapon {
                                // Finally if actor does not have such weapon, give new one to him.
                                script_message_sender.send_to_target(
                                    self_handle,
                                    CharacterMessage {
                                        character: self_handle,
                                        data: CharacterMessageData::AddWeapon(item_resource),
                                    },
                                );
                            }
                        }
                    }

                    sound_manager.play_sound(
                        &mut scene.graph,
                        "data/sounds/item_pickup.ogg",
                        position,
                        1.0,
                        3.0,
                        2.0,
                    );

                    scene.graph[item_handle].set_enabled(false);
                }
            }
            CharacterMessageData::DropItems { item, count } => {
                let drop_position = self.position + Vector3::new(0.0, 0.5, 0.0);
                let weapons = self.weapons().to_vec();

                if self.inventory.try_extract_exact_items(item, *count) == *count {
                    // Make sure to remove weapons associated with items.
                    for &weapon in weapons.iter() {
                        if scene.graph[weapon].root_resource() == Some(item.clone()) {
                            scene.graph.remove_node(weapon);
                        }
                    }

                    Item::add_to_scene(scene, item.clone(), drop_position, true, *count);
                }
            }
            CharacterMessageData::UseItem {
                item: item_resource,
            } => {
                Item::from_resource(item_resource, |item| {
                    if let Some(item) = item {
                        if *item.consumable
                            && self
                                .inventory_mut()
                                .try_extract_exact_items(item_resource, 1)
                                == 1
                        {
                            self.use_item(item, &scene.graph, script_message_sender);
                        } else {
                            script_message_sender.send_to_target(
                                self_handle,
                                CharacterMessage {
                                    character: self_handle,
                                    data: CharacterMessageData::SelectWeapon(item_resource.clone()),
                                },
                            );
                        }
                    }
                });
            }
            _ => (),
        }
    }

    pub fn select_weapon(&mut self, weapon: ModelResource, graph: &mut Graph) {
        if let Some(index) = self
            .weapons
            .iter()
            .position(|&w| graph[w].root_resource() == Some(weapon.clone()))
        {
            for &other_weapon in self.weapons.iter() {
                graph[other_weapon].set_enabled(false);
            }

            self.current_weapon = index;

            self.set_current_weapon_enabled(true, graph);
        }
    }

    pub fn current_weapon(&self) -> Handle<Node> {
        self.weapons
            .get(self.current_weapon)
            .cloned()
            .unwrap_or_default()
    }

    fn set_current_weapon_enabled(&self, state: bool, graph: &mut Graph) {
        if let Some(current_weapon) = self.weapons.get(self.current_weapon) {
            graph[*current_weapon].set_enabled(state);
        }
    }

    pub fn next_weapon(&mut self, graph: &mut Graph) {
        if !self.weapons.is_empty() && (self.current_weapon) < self.weapons.len() - 1 {
            self.set_current_weapon_enabled(false, graph);

            self.current_weapon += 1;

            self.set_current_weapon_enabled(true, graph);
        }
    }

    pub fn prev_weapon(&mut self, graph: &mut Graph) {
        if self.current_weapon > 0 {
            self.set_current_weapon_enabled(false, graph);

            self.current_weapon -= 1;

            self.set_current_weapon_enabled(true, graph);
        }
    }

    pub fn use_first_weapon_or_none(&mut self, graph: &mut Graph) {
        if !self.weapons.is_empty() {
            self.set_current_weapon_enabled(false, graph);

            self.current_weapon = 0;

            self.set_current_weapon_enabled(true, graph);
        }
    }

    pub fn set_current_weapon(&mut self, i: usize, graph: &mut Graph) {
        if i < self.weapons.len() {
            self.set_current_weapon_enabled(false, graph);

            self.current_weapon = i;

            self.set_current_weapon_enabled(true, graph);
        }
    }

    pub fn inventory(&self) -> &Inventory {
        &self.inventory
    }

    pub fn inventory_mut(&mut self) -> &mut Inventory {
        &mut self.inventory
    }

    pub fn footstep_ray_check(
        &self,
        begin: Vector3<f32>,
        scene: &mut Scene,
        manager: &SoundManager,
    ) {
        let mut query_buffer = Vec::new();

        let ray = Ray::from_two_points(begin, begin + Vector3::new(0.0, -100.0, 0.0));

        scene.graph.physics.cast_ray(
            RayCastOptions {
                ray_origin: Point3::from(ray.origin),
                ray_direction: ray.dir,
                max_len: 100.0,
                groups: Default::default(),
                sort_results: true,
            },
            &mut query_buffer,
        );

        for intersection in query_buffer
            .into_iter()
            .filter(|i| i.collider != self.capsule_collider)
        {
            manager.play_environment_sound(
                &mut scene.graph,
                intersection.collider,
                intersection.feature,
                intersection.position.coords,
                SoundKind::FootStep,
                0.45,
                1.0,
                0.3,
            );
        }
    }
}
