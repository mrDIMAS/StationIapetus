use crate::{
    bot::behavior::BehaviorContext, door::door_mut, level::hit_box::HitBox,
    utils::BodyImpactHandler, Game,
};
use fyrox::{
    core::{algebra::Vector3, pool::Handle, visitor::prelude::*},
    fxhash::FxHashSet,
    graph::{SceneGraph, SceneGraphNode},
    plugin::error::GameError,
    scene::{collider::Collider, navmesh::NavigationalMesh, Scene},
    utils::behavior::{Behavior, Status},
};

#[derive(Default, Debug, PartialEq, Visit, Clone)]
pub struct MoveToTarget {
    pub min_distance: f32,
}

impl MoveToTarget {
    fn check_obstacles(&self, self_position: Vector3<f32>, ctx: &mut BehaviorContext) {
        let doors = &ctx
            .plugins
            .get::<Game>()
            .level
            .as_ref()
            .expect("Level must exist!")
            .doors_container
            .doors;
        for &door in doors {
            let door = door_mut(door, &mut ctx.scene.graph);
            let close_enough = self_position.metric_distance(&door.initial_position()) < 1.25;
            if close_enough {
                door.try_open(Some(&ctx.character.inventory));
            }
        }
    }
}

fn calculate_movement_speed_factor(
    hit_boxes: &FxHashSet<Handle<Collider>>,
    impact_handler: &BodyImpactHandler,
    scene: &Scene,
) -> Result<f32, GameError> {
    let mut k = 1.0;

    // Slowdown bot according to damaged body parts.
    for hit_box_handle in hit_boxes.iter() {
        let hit_box_node = scene.graph.try_get(*hit_box_handle)?;
        if let Some(hit_box_ref) = hit_box_node.try_get_script::<HitBox>() {
            let body = hit_box_node.parent();
            if impact_handler.is_affected(body) {
                k = hit_box_ref.movement_speed_factor.min(k);
            }
        }
    }

    Ok(k)
}

impl<'a> Behavior<'a> for MoveToTarget {
    type Context = BehaviorContext<'a>;

    fn tick(&mut self, ctx: &mut Self::Context) -> Result<Status, GameError> {
        ctx.movement_speed_factor = calculate_movement_speed_factor(
            &ctx.character.hit_boxes,
            ctx.impact_handler,
            ctx.scene,
        )?;

        let transform = &ctx.scene.graph.try_get(ctx.model)?.global_transform();

        let delta_position = ctx
            .state_machine
            .lower_body_layer(&ctx.scene.graph)
            .and_then(|layer| layer.pose().root_motion().map(|rm| rm.delta_position));

        ctx.agent.set_speed(ctx.move_speed);
        ctx.agent.set_position(ctx.character.position);

        if let Some(target) = ctx.target.as_ref() {
            ctx.agent.set_target(target.position);

            // keep all borrows from MultiBorrowcontext inside this scope
            {
                let multiborrow_context = ctx.scene.graph.begin_multi_borrow();

                let navmesh_node = multiborrow_context.try_get(ctx.navmesh)?;

                let navmesh = navmesh_node
                    .component_ref::<NavigationalMesh>()
                    .ok_or_else(|| {
                        GameError::str("Navmesh node has no NavigationalMesh component")
                    })?;

                let _ = ctx.agent.update(ctx.dt, &navmesh.navmesh_ref());
            }
        }
        let has_reached_destination =
            ctx.agent.target().metric_distance(&ctx.character.position) <= self.min_distance;

        if has_reached_destination {
            ctx.character.velocity.x = 0.0;
            ctx.character.velocity.z = 0.0;
        } else if let Some(delta_position) = delta_position {
            let vel = transform.transform_vector(&delta_position);

            ctx.character.velocity.x = vel.x;
            ctx.character.velocity.z = vel.z;
        }

        // All MultiBorrowContext/Ref borrows have ended here.
        self.check_obstacles(ctx.character.position, ctx);

        if has_reached_destination {
            ctx.is_moving = false;
            Ok(Status::Success)
        } else {
            ctx.is_moving = true;
            Ok(Status::Running)
        }
    }
}
