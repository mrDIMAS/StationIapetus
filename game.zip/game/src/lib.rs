#![allow(clippy::too_many_arguments)]

pub mod bot;
pub mod character;
pub mod config;
pub mod control_scheme;
pub mod door;
pub mod effects;
pub mod elevator;
pub mod gui;
pub mod highlight;
pub mod inventory;
pub mod level;
pub mod light;
pub mod message;
pub mod player;
pub mod sound;
pub mod utils;
pub mod weapon;

pub use fyrox;

use crate::gui::final_screen::FinalScreenData;
use crate::{
    bot::{Bot, BotHostility},
    character::Character,
    config::Config,
    door::Door,
    effects::{beam::Beam, rail::Rail},
    elevator::{
        call_button::{CallButton, CallButtonKind},
        Elevator,
    },
    gui::death_screen::DeathScreenData,
    gui::final_screen::FinalScreen,
    gui::{
        inventory::InventoryItem, item_display::ItemDisplay, journal::JournalDisplay,
        loading_screen::LoadingScreen, menu::Menu, menu::MenuData, weapon_display::WeaponDisplay,
    },
    highlight::HighlightRenderPass,
    inventory::{Inventory, ItemEntry},
    level::{
        arrival::enemy_trap::EnemyTrap,
        death_zone::DeathZone,
        decal::Decal,
        explosion::Explosion,
        explosive_barrel::ExplosiveBarrel,
        hit_box::{HitBox, LimbType},
        item::{Item, ItemAction},
        point_of_interest::PointOfInterest,
        spawn::CharacterSpawnPoint,
        trigger::{BotCounter, Trigger, TriggerAction},
        turret::{Barrel, Hostility, ShootMode, Turret},
        Level,
    },
    light::AnimatedLight,
    message::Message,
    player::{camera::CameraController, Player},
    sound::SoundManager,
    utils::use_hrtf,
    weapon::{
        kinetic::KineticGun,
        projectile::{Damage, Projectile},
        sight::LaserSight,
        CombatWeaponKind, Weapon,
    },
};
use fyrox::{
    core::{
        algebra::Vector2,
        color::Color,
        futures::executor::block_on,
        log::Log,
        pool::Handle,
        reflect::prelude::*,
        type_traits::TypeUuidProvider,
        uuid::{uuid, Uuid},
        visitor::{Visit, VisitResult, Visitor},
    },
    dpi::LogicalSize,
    engine::GraphicsContext,
    event::{ElementState, Event, WindowEvent},
    gui::{
        button::ButtonMessage,
        check_box::CheckBoxMessage,
        font::{Font, FontResource},
        inspector::editors::PropertyEditorDefinitionContainer,
        message::{MessageDirection, UiMessage},
        text::{Text, TextBuilder, TextMessage},
        widget::{WidgetBuilder, WidgetMessage},
        UiNode, UserInterface,
    },
    keyboard::KeyCode,
    plugin::{
        error::GameResult, Plugin, PluginContext, PluginRegistrationContext, SceneLoaderOutput,
        SceneLoaderResult,
    },
    renderer::ui_renderer::UiRenderInfo,
    scene::{
        base::BaseBuilder,
        sound::{SoundBuffer, SoundBuilder, Status},
    },
    utils::translate_event,
    window::CursorGrabMode,
};
use gui::death_screen::DeathScreen;
use std::{
    cell::RefCell,
    path::{Path, PathBuf},
    rc::Rc,
    sync::{
        mpsc::{self, Receiver, Sender},
        Arc,
    },
};

#[derive(Visit, Reflect, Debug, TypeUuidProvider)]
#[reflect(hide_all, non_cloneable)]
#[type_uuid(id = "dba407d5-90bd-4874-89ae-edd0ab9b64e2")]
pub struct Game {
    menu: Option<Menu>,
    level: Option<Level>,
    debug_text: Handle<Text>,
    debug_string: String,
    running: bool,
    #[visit(skip)]
    #[reflect(hidden)]
    config: Config,
    #[visit(skip)]
    message_receiver: Receiver<Message>,
    #[visit(skip)]
    message_sender: MessageSender,
    loading_screen: LoadingScreen,
    death_screen: Option<DeathScreen>,
    final_screen: Option<FinalScreen>,
    weapon_display: WeaponDisplay,
    item_display: ItemDisplay,
    journal_display: JournalDisplay,
    #[visit(skip)]
    highlighter: Option<Rc<RefCell<HighlightRenderPass>>>,
    font: FontResource,
}

impl Default for Game {
    fn default() -> Self {
        let (tx, rx) = mpsc::channel();
        Self {
            config: Config::load(),
            menu: Default::default(),
            level: None,
            debug_text: Default::default(),
            debug_string: Default::default(),
            running: Default::default(),
            message_receiver: rx,
            message_sender: MessageSender { sender: tx },
            loading_screen: Default::default(),
            death_screen: Default::default(),
            final_screen: Default::default(),
            weapon_display: Default::default(),
            item_display: Default::default(),
            journal_display: Default::default(),
            highlighter: Default::default(),
            font: Default::default(),
        }
    }
}

#[repr(u16)]
pub enum CollisionGroups {
    ActorCapsule = 1 << 0,
    All = u16::MAX,
}

#[derive(Clone, Debug)]
pub struct MessageSender {
    sender: Sender<Message>,
}

impl MessageSender {
    pub fn send(&self, message: Message) {
        Log::verify(self.sender.send(message))
    }
}

impl Game {
    fn handle_ui_message(
        &mut self,
        ctx: &mut PluginContext,
        message: &UiMessage,
        ui_handle: Handle<UserInterface>,
    ) -> GameResult {
        if let Some(menu) = self.menu.as_mut() {
            menu.handle_ui_message(
                ctx,
                ui_handle,
                message,
                &mut self.config,
                &self.message_sender,
            )?;
        };

        if let Some(death_screen) = self.death_screen.take() {
            self.death_screen =
                death_screen.handle_ui_message(ctx, ui_handle, message, &self.message_sender);
        }

        if let Some(final_screen) = self.final_screen.take() {
            self.final_screen =
                final_screen.handle_ui_message(ctx, ui_handle, message, &self.message_sender);
        }

        let play_sound = if message.direction() == MessageDirection::FromWidget {
            if let Some(ButtonMessage::Click) = message.data() {
                true
            } else {
                matches!(message.data(), Some(CheckBoxMessage::Check(_)))
            }
        } else {
            false
        };

        if play_sound {
            self.message_sender.send(Message::Play2DSound {
                path: PathBuf::from("data/sounds/click.ogg"),
                gain: 0.8,
            });
        }

        Ok(())
    }

    fn render_offscreen(&mut self, context: &mut PluginContext) {
        if let GraphicsContext::Initialized(ref mut graphics_context) = context.graphics_context {
            let renderer = &mut graphics_context.renderer;

            for (rt, ui) in [
                (
                    self.weapon_display.render_target.clone(),
                    &mut self.weapon_display.ui,
                ),
                (
                    self.item_display.render_target.clone(),
                    &mut self.item_display.ui,
                ),
                (
                    self.journal_display.render_target.clone(),
                    &mut self.journal_display.ui,
                ),
            ] {
                Log::verify(renderer.render_ui(UiRenderInfo {
                    ui,
                    render_target: Some(rt),
                    clear_color: Color::TRANSPARENT,
                    resource_manager: context.resource_manager,
                }));
            }
        }
    }

    fn debug_render(&mut self, context: &mut PluginContext) -> GameResult {
        if let Some(level) = self.level.as_mut() {
            level.debug_draw(context)?;
        }
        Ok(())
    }

    pub fn create_debug_ui(&mut self, context: &mut PluginContext) {
        self.debug_text = TextBuilder::new(WidgetBuilder::new().with_width(400.0))
            .build(&mut context.user_interfaces.first_mut().build_ctx());
    }

    pub fn save_game(&mut self, path: &Path, context: &mut PluginContext) -> VisitResult {
        if let Some(level) = self.level.as_mut() {
            let mut visitor = Visitor::new();

            context.scenes[level.scene].save("Scene", &mut visitor)?;
            level.visit("Level", &mut visitor)?;

            // Debug output
            let mut debug_path = path.to_path_buf();
            debug_path.set_extension("txt");
            visitor.save_ascii_to_file(debug_path)?;
            visitor.save_binary_to_file(path)
        } else {
            Ok(())
        }
    }

    fn destroy_level(&mut self, context: &mut PluginContext) {
        if let Some(ref mut level) = self.level.take() {
            level.destroy(context);
            Log::info("Current level destroyed!");
        }
    }

    fn try_destroy_death_screen(&mut self, ctx: &mut PluginContext) {
        if let Some(death_screen) = self.death_screen.take() {
            death_screen.destroy(ctx);
        }
    }

    fn try_destroy_final_screen(&mut self, ctx: &mut PluginContext) {
        if let Some(final_screen) = self.final_screen.take() {
            final_screen.destroy(ctx);
        }
    }

    pub fn before_load_level(&mut self, ctx: &mut PluginContext) -> GameResult {
        self.destroy_level(ctx);
        self.try_destroy_death_screen(ctx);
        self.try_destroy_final_screen(ctx);
        let ui = ctx.user_interfaces.first();
        ui.send(self.loading_screen.root, WidgetMessage::Visibility(true));
        if let Some(menu) = self.menu.as_mut() {
            menu.set_visible(ctx, false)?;
        }
        Ok(())
    }

    pub fn on_level_loaded(
        &mut self,
        result: SceneLoaderResult,
        ctx: &mut PluginContext,
    ) -> GameResult {
        let SceneLoaderOutput {
            payload: scene,
            data,
            ..
        } = result?;

        let scene = ctx.scenes.add(scene);

        if let Some(highlighter) = self.highlighter.as_mut() {
            highlighter.borrow_mut().scene_handle = scene;
        }

        if let Ok(mut visitor) = Visitor::load_from_memory(&data) {
            let mut level = Level::default();
            if level.visit("Level", &mut visitor).is_ok() {
                // Means that we're loading a saved game.
                level.scene = scene;
                level.resolve(ctx, self.message_sender.clone());
                self.level = Some(level);
            } else {
                self.level = Some(Level::from_existing_scene(
                    44100,
                    &mut ctx.scenes[scene],
                    scene,
                    self.message_sender.clone(),
                    self.config.sound.clone(),
                    ctx.resource_manager.clone(),
                ));
            }
        }

        self.set_menu_visible(false, ctx)?;
        ctx.user_interfaces
            .first()
            .send(self.loading_screen.root, WidgetMessage::Visibility(false));

        if let Some(menu) = self.menu.as_mut() {
            menu.sync_to_model(ctx, true)?;
        }

        Log::info("Level was loaded successfully!");

        Ok(())
    }

    pub fn load_level(&mut self, path: PathBuf, ctx: &mut PluginContext) -> GameResult {
        self.before_load_level(ctx)?;
        ctx.load_scene(path, true, |result, game: &mut Game, ctx| {
            game.on_level_loaded(result, ctx)
        });
        Ok(())
    }

    pub fn load_game(&mut self, path: PathBuf, ctx: &mut PluginContext) -> GameResult {
        self.before_load_level(ctx)?;
        ctx.load_scene(path, false, |result, game: &mut Game, ctx| {
            game.on_level_loaded(result, ctx)
        });
        Ok(())
    }

    pub fn set_menu_visible(&mut self, visible: bool, context: &mut PluginContext) -> GameResult {
        if let Some(menu) = self.menu.as_mut() {
            menu.set_visible(context, visible)?;
        }
        Ok(())
    }

    pub fn is_any_menu_visible(&self, context: &PluginContext) -> bool {
        self.menu
            .as_ref()
            .is_some_and(|menu| menu.is_visible(context))
            || self.death_screen.is_some()
            || self.final_screen.is_some()
    }

    pub fn update(&mut self, ctx: &mut PluginContext) -> GameResult {
        let debug = true;

        self.config.save_if_needed();

        if let GraphicsContext::Initialized(ref graphics_context) = ctx.graphics_context {
            let window = &graphics_context.window;
            window.set_cursor_visible(self.is_any_menu_visible(ctx));

            if !debug {
                let _ = window.set_cursor_grab(if !self.is_any_menu_visible(ctx) {
                    CursorGrabMode::Confined
                } else {
                    CursorGrabMode::None
                });
            }
        }

        let ui = ctx.user_interfaces.first();

        self.loading_screen.set_progress(
            ui,
            ctx.resource_manager.state().loading_progress() as f32 / 100.0,
        );

        if let Some(ref mut level) = self.level {
            if let Some(menu) = self.menu.as_ref() {
                let enabled = !menu.is_visible(ctx);
                ctx.scenes[level.scene].enabled.set_value_silent(enabled);
            }
        }

        if let Some(menu) = self.menu.as_ref() {
            menu.update(ctx)?;
        }

        self.weapon_display.update(ctx.dt);
        self.item_display.update(ctx.dt);

        for scene in ctx.scenes.iter_mut() {
            scene
                .graph
                .sound_context
                .state()
                .bus_graph_mut()
                .primary_bus_mut()
                .set_gain(self.config.sound.master_volume);
        }

        self.handle_messages(ctx)?;

        self.update_statistics(0.0, ctx);

        // <<<<<<<<< ENABLE THIS FOR DEBUGGING
        if false {
            self.debug_render(ctx)?;
        }

        Ok(())
    }

    fn handle_messages(&mut self, context: &mut PluginContext) -> GameResult {
        while let Ok(message) = self.message_receiver.try_recv() {
            match &message {
                Message::StartNewGame => {
                    self.load_level(Level::ARRIVAL_PATH.into(), context)?;
                }
                Message::SaveGame(path) => match self.save_game(path, context) {
                    Ok(_) => Log::info("Successfully saved"),
                    Err(e) => Log::err(format!("Failed to make a save at {path:?}, reason: {e}")),
                },
                Message::LoadGame(path) => {
                    self.load_game(path.clone(), context)?;
                }
                Message::LoadLevel { path } => {
                    self.load_level(path.clone(), context)?;
                }
                Message::QuitGame => {
                    self.destroy_level(context);
                    self.running = false;
                }
                Message::EndMatch => {
                    self.destroy_level(context);
                    context.load_ui("data/ui/death_screen.ui", |result, game: &mut Game, ctx| {
                        game.death_screen = Some(DeathScreen::new(result?.payload, ctx));
                        Ok(())
                    });
                    if let Some(menu) = self.menu.as_mut() {
                        menu.sync_to_model(context, false)?;
                    }
                }
                Message::EndGame => {
                    self.destroy_level(context);
                    context.load_ui("data/ui/final_screen.ui", |result, game: &mut Game, ctx| {
                        game.final_screen = Some(FinalScreen::new(result?.payload, ctx));
                        Ok(())
                    });
                    if let Some(menu) = self.menu.as_mut() {
                        menu.sync_to_model(context, false)?;
                    }
                }
                Message::SetMusicVolume(volume) => {
                    self.config.sound.music_volume = *volume;
                    if let Some(menu) = self.menu.as_mut() {
                        if let Some(scene) = menu.scene.as_ref() {
                            // TODO: Apply to sound manager of level when it will handle music!
                            context.scenes[scene.scene].graph[scene.music].set_gain(*volume);
                        }
                    }
                }
                Message::SetUseHrtf(state) => {
                    self.config.sound.use_hrtf = *state;
                    // Hrtf is applied **only** to game scene!
                    if let Some(level) = self.level.as_ref() {
                        let scene = &mut context.scenes[level.scene];
                        if self.config.sound.use_hrtf {
                            block_on(use_hrtf(
                                44100,
                                &mut scene.graph.sound_context,
                                context.resource_manager,
                            ))
                        } else {
                            scene
                                .graph
                                .sound_context
                                .state()
                                .set_renderer(fyrox::scene::sound::Renderer::Default);
                        }
                    }
                }
                Message::SetMasterVolume(volume) => {
                    self.config.sound.master_volume = *volume;
                }
                Message::ToggleMainMenu => {
                    if let Some(menu) = self.menu.as_mut() {
                        menu.set_visible(context, true)?;
                    }
                    self.try_destroy_death_screen(context);
                    self.try_destroy_final_screen(context);
                }
                Message::SyncJournal => {
                    if let Some(ref mut level) = self.level {
                        let player_ref = context.scenes[level.scene].graph[level.player]
                            .try_get_script::<Player>()
                            .unwrap();
                        self.journal_display.sync_to_model(&player_ref.journal);
                    }
                }
                Message::Play2DSound { path, gain } => {
                    if let Ok(buffer) = fyrox::core::futures::executor::block_on(
                        context.resource_manager.request::<SoundBuffer>(path),
                    ) {
                        if let Some(menu) = self.menu.as_mut() {
                            if let Some(scene) = menu.scene.as_ref() {
                                let menu_scene = &mut context.scenes[scene.scene];
                                SoundBuilder::new(BaseBuilder::new())
                                    .with_buffer(buffer.into())
                                    .with_status(Status::Playing)
                                    .with_play_once(true)
                                    .with_gain(*gain)
                                    .build(&mut menu_scene.graph);
                            }
                        }
                    }
                }
            }
        }
        Ok(())
    }

    pub fn update_statistics(&mut self, elapsed: f64, ctx: &mut PluginContext) {
        let ui = ctx.user_interfaces.first_mut();

        if self.config.show_debug_info {
            if let GraphicsContext::Initialized(ref graphics_context) = ctx.graphics_context {
                self.debug_string.clear();
                use std::fmt::Write;
                write!(
                    self.debug_string,
                    "Up time: {:.1}\n{}{}\n{}",
                    elapsed,
                    graphics_context.renderer.get_statistics(),
                    if let Some(level) = self.level.as_ref() {
                        ctx.scenes[level.scene].performance_statistics.clone()
                    } else {
                        Default::default()
                    },
                    ctx.performance_statistics,
                )
                .unwrap();

                if let Some(ref mut level) = self.level {
                    write!(
                        self.debug_string,
                        "Node Count: {}",
                        ctx.scenes[level.scene].graph.node_count()
                    )
                    .unwrap();
                }

                ui.send(
                    self.debug_text,
                    TextMessage::Text(self.debug_string.clone()),
                );
            }
        }

        ui.send(
            self.debug_text,
            WidgetMessage::Visibility(self.config.show_debug_info),
        );
    }

    fn process_dispatched_event(&mut self, event: &Event<()>) {
        if let Event::WindowEvent { event, .. } = event {
            if let Some(event) = translate_event(event) {
                self.journal_display
                    .process_os_event(&event, &self.config.controls);
            }
        }
    }

    pub fn on_window_resized(
        &mut self,
        ui: &UserInterface,
        graphics_context: &mut GraphicsContext,
        width: f32,
        height: f32,
    ) {
        self.loading_screen.resize(ui, width, height);
        self.create_highlighter(graphics_context, width as usize, height as usize);
    }

    fn create_highlighter(
        &mut self,
        graphics_context: &mut GraphicsContext,
        width: usize,
        height: usize,
    ) {
        if let GraphicsContext::Initialized(graphics_context) = graphics_context {
            if let Some(highlighter) = self.highlighter.as_ref() {
                graphics_context
                    .renderer
                    .remove_render_pass(highlighter.clone());
            }

            let highlighter =
                HighlightRenderPass::new(&*graphics_context.renderer.server, width, height);

            if let Some(level) = self.level.as_ref() {
                highlighter.borrow_mut().scene_handle = level.scene;
            }

            graphics_context
                .renderer
                .add_render_pass(highlighter.clone());

            self.highlighter = Some(highlighter);
        }
    }

    pub fn process_input_event(
        &mut self,
        event: &Event<()>,
        context: &mut PluginContext,
    ) -> GameResult {
        self.process_dispatched_event(event);

        if let Event::WindowEvent {
            event: WindowEvent::KeyboardInput { event: input, .. },
            ..
        } = event
        {
            if let ElementState::Pressed = input.state {
                if input.physical_key == KeyCode::Escape && self.level.is_some() {
                    self.set_menu_visible(!self.is_any_menu_visible(context), context)?;
                }
            }
        }

        if let Some(menu) = self.menu.as_mut() {
            menu.process_input_event(context, event, &mut self.config)?;
        }

        Ok(())
    }
}

impl Plugin for Game {
    fn register(&self, ctx: PluginRegistrationContext) -> GameResult {
        ctx.serialization_context
            .script_constructors
            .add::<Door>("Door")
            .add::<Turret>("Turret")
            .add::<Weapon>("Weapon")
            .add::<Item>("Item")
            .add::<Decal>("Decal")
            .add::<Player>("Player")
            .add::<CameraController>("Camera Controller")
            .add::<Bot>("Bot")
            .add::<CharacterSpawnPoint>("Character Spawn Point")
            .add::<DeathZone>("Death Zone")
            .add::<AnimatedLight>("Animated Light")
            .add::<Elevator>("Elevator")
            .add::<CallButton>("Call Button")
            .add::<Projectile>("Projectile")
            .add::<LaserSight>("LaserSight")
            .add::<Rail>("Rail")
            .add::<Explosion>("Explosion")
            .add::<Beam>("Beam")
            .add::<KineticGun>("KineticGun")
            .add::<EnemyTrap>("ArrivalEnemyTrap")
            .add::<PointOfInterest>("Point Of Interest")
            .add::<Trigger>("Trigger")
            .add::<ExplosiveBarrel>("ExplosiveBarrel")
            .add::<HitBox>("HitBox");

        ctx.dyn_type_constructors
            .add::<MenuData, Self>("Menu Data")
            .add::<DeathScreenData, Self>("Death Screen Data")
            .add::<FinalScreenData, Self>("Final Screen Data");

        ctx.widget_constructors.add::<InventoryItem>();

        Ok(())
    }

    fn register_property_editors(&self, container: Arc<PropertyEditorDefinitionContainer>) {
        // Scripts.
        container.register_inheritable_inspectable::<Door>();
        container.register_inheritable_inspectable::<Turret>();
        container.register_inheritable_inspectable::<Weapon>();
        container.register_inheritable_inspectable::<Item>();
        container.register_inheritable_inspectable::<Decal>();
        container.register_inheritable_inspectable::<Player>();
        container.register_inheritable_inspectable::<Bot>();
        container.register_inheritable_inspectable::<CharacterSpawnPoint>();
        container.register_inheritable_inspectable::<DeathZone>();
        container.register_inheritable_inspectable::<AnimatedLight>();
        container.register_inheritable_inspectable::<Elevator>();
        container.register_inheritable_inspectable::<CallButton>();
        container.register_inheritable_inspectable::<Projectile>();
        container.register_inheritable_inspectable::<LaserSight>();
        container.register_inheritable_inspectable::<Rail>();
        container.register_inheritable_inspectable::<Explosion>();
        container.register_inheritable_inspectable::<Beam>();
        container.register_inheritable_inspectable::<KineticGun>();
        container.register_inheritable_inspectable::<EnemyTrap>();
        container.register_inheritable_inspectable::<PointOfInterest>();
        container.register_inheritable_inspectable::<Trigger>();
        container.register_inheritable_inspectable::<ExplosiveBarrel>();
        container.register_inheritable_inspectable::<HitBox>();

        // Other.
        container.register_inheritable_enum::<Hostility, _>();
        container.register_inheritable_enum::<ShootMode, _>();
        container.register_inheritable_enum::<CombatWeaponKind, _>();
        container.register_inheritable_enum::<CallButtonKind, _>();
        container.register_inheritable_enum::<Damage, _>();
        container.register_inheritable_enum::<TriggerAction, _>();
        container.register_inheritable_enum::<BotHostility, _>();
        container.register_inheritable_enum::<ItemAction, _>();
        container.register_inheritable_enum::<LimbType, _>();
        container.register_inheritable_inspectable::<Inventory>();
        container.register_inheritable_inspectable::<ItemEntry>();
        container.register_inheritable_inspectable::<Barrel>();
        container.register_inheritable_inspectable::<Character>();
        container.register_inheritable_inspectable::<CameraController>();
        container.register_inheritable_inspectable::<BotCounter>();
        container.register_inheritable_vec_collection::<Barrel>();
        container.register_inheritable_vec_collection::<ItemEntry>();
    }

    fn init(&mut self, scene_path: Option<&str>, mut ctx: PluginContext) -> GameResult {
        ctx.user_interfaces
            .add(UserInterface::new(Vector2::repeat(100.0)));

        if let Some(scene_path) = scene_path {
            self.load_level(PathBuf::from(scene_path), &mut ctx)?;
        }

        println!("cwd = {:?}", std::env::current_dir());

        let path = std::path::Path::new("data/ui/SquaresBold.ttf");

        println!("font path = {:?}", path);
        println!("font exists = {}", path.exists());
        println!("font absolute = {:?}", std::fs::canonicalize(path));

        let font = ctx
            .resource_manager
            .request::<Font>(Path::new("data/ui/SquaresBold.ttf"));

        let (tx, rx) = mpsc::channel();

        let message_sender = MessageSender { sender: tx };
        let weapon_display = WeaponDisplay::new(font.clone(), ctx.resource_manager.clone());

        let item_display = ItemDisplay::new(font.clone());
        let journal_display = JournalDisplay::new();

        ctx.load_ui("data/ui/main_menu.ui", |result, game: &mut Game, ctx| {
            game.menu = Some(Menu::new(result?.payload, ctx, game.font.clone()));
            Ok(())
        });

        *self = Game {
            config: self.config.clone(),
            loading_screen: LoadingScreen::new(&mut ctx.user_interfaces.first_mut().build_ctx()),
            running: true,
            menu: None,
            death_screen: None,
            final_screen: None,
            debug_text: Handle::NONE,
            weapon_display,
            item_display,
            journal_display,
            level: None,
            debug_string: String::new(),
            message_receiver: rx,
            message_sender,
            highlighter: None,
            font,
        };

        self.create_debug_ui(&mut ctx);

        Ok(())
    }

    fn update(&mut self, ctx: &mut PluginContext) -> GameResult {
        self.update(ctx)?;

        if !self.running {
            ctx.loop_controller.exit();
        }

        Ok(())
    }

    fn on_os_event(&mut self, event: &Event<()>, mut ctx: PluginContext) -> GameResult {
        self.process_input_event(event, &mut ctx)?;

        if let Event::WindowEvent { event, .. } = event {
            match event {
                WindowEvent::CloseRequested => {
                    self.destroy_level(&mut ctx);
                    ctx.loop_controller.exit();
                }
                WindowEvent::Resized(new_size) => self.on_window_resized(
                    ctx.user_interfaces.first(),
                    ctx.graphics_context,
                    new_size.width as f32,
                    new_size.height as f32,
                ),
                _ => (),
            }
        }

        Ok(())
    }

    fn on_loaded(&mut self, context: PluginContext) -> GameResult {
        if let GraphicsContext::Initialized(ref graphics_context) = context.graphics_context {
            let inner_size = graphics_context.window.inner_size();

            self.create_highlighter(
                context.graphics_context,
                inner_size.width as usize,
                inner_size.height as usize,
            );
        }

        if let Some(level) = self.level.as_mut() {
            let scene = &mut context.scenes[level.scene];
            level.sound_manager = SoundManager::new(scene, context.resource_manager.clone());
        }

        Ok(())
    }

    fn on_graphics_context_initialized(&mut self, mut context: PluginContext) -> GameResult {
        let graphics_context = context.graphics_context.as_initialized_mut();

        let inner_size = if let Some(primary_monitor) = graphics_context.window.primary_monitor() {
            let mut monitor_dimensions = primary_monitor.size();
            monitor_dimensions.height = (monitor_dimensions.height as f32 * 0.7) as u32;
            monitor_dimensions.width = (monitor_dimensions.width as f32 * 0.7) as u32;
            monitor_dimensions.to_logical::<f32>(primary_monitor.scale_factor())
        } else {
            LogicalSize::new(1024.0, 768.0)
        };

        let window = &graphics_context.window;
        window.set_title("Station Iapetus");
        window.set_resizable(true);
        let _ = window.request_inner_size(inner_size);

        self.on_window_resized(
            context.user_interfaces.first(),
            context.graphics_context,
            inner_size.width,
            inner_size.height,
        );
        if let Some(menu) = self.menu.as_mut() {
            menu.sync_to_model(&mut context, self.level.is_some())?;
        }

        Ok(())
    }

    fn before_rendering(&mut self, mut context: PluginContext) -> GameResult {
        self.render_offscreen(&mut context);
        Ok(())
    }

    fn on_ui_message(
        &mut self,
        context: &mut PluginContext,
        message: &UiMessage,
        ui_handle: Handle<UserInterface>,
    ) -> GameResult {
        self.handle_ui_message(context, message, ui_handle)?;
        Ok(())
    }
}
